'''Ejercicio 8
Escribir un programa que pida al usuario dos números enteros y muestre por pantalla la <n> 
entre <m> da un cociente <c> 
y un resto <r> donde <n> y <m> son los números introducidos por el usuario,
 y <c> y <r> son el cociente y el resto de la división entera respectivamente.'''




n=input('Ingrese primer numero:')
m=input('Ingrese segundo numero:')
n=int(n)
m=int(m)

c=(n//m)
c= int(c)
r=(n%m)
r=float(r)

print(" La division entre "  +  str(n)  +  " y "  +  str(m)  +  " es igual a "  +  str(c)  +  " y un residuo "  +  str(r))



