"""
Ejercicio 6
Escribir un programa que lea un entero n positivo, , introducido por el usuario y
 después muestre en pantalla la suma de todos los enteros desde 1 hasta n .

"""
print('Ingrese numero entero positivo')
n=input()
n=int(n)

suma= n*(n+1)//2


print("La suma de 1 hasta " + str(n) + " es " + str(suma))


