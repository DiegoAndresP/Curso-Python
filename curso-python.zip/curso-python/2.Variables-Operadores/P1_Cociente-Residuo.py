
"""Practica 01: Calcular cociente y el Residuo de dos números enteros
Enunciado: Hallar el cociente y el residuo (resto) de dos números enteros.

Análisis: para la solución de este problema, se requiere que el usuario 
ingrese dos números enteros y el sistema realice el cálculo respectivo 
para hallar el cociente y residuo, para esto use la siguiente expresión."""

print('Calculo de Cociente y Residuo de 2 numeros')

a=input('Ingrese primer numero:')
b=input('Ingrese segundo numero:')

a=int(a)
b=int(b)

Cociente= a//b
Residuo=a%b

print('El cociente =',Cociente)
print('El residuo=',Residuo)
