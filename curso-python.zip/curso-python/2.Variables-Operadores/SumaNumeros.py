#Suma de 2 numeros

print('Ingrese 2 numeros')

a=input('Ingrese primer numero:')
b=input('Ingrese segundo numero:')

a=int(a)
b=int(b)

suma=a+b

print('La suma es =',suma)
