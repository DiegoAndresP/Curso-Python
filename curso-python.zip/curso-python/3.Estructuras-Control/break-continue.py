from ast import Break


c=0
while c<10:
    c+=1
    print(c)
    #BREAK SIMPLEMENTE NOS SACA DEL BUCLE 
    if c==5:
        #print('TERMINA BUCLE')
        print('Siguiente Iteracion')
        #break
        continue
    
    print('Despues de continue')

    #USO DE ELSE
else:
    print('FIN BUCLE')

