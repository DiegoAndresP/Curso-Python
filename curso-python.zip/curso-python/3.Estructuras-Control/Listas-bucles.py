datos=['Diego', 'Andres', 20, 1.77, True]
'''
CON BUCLE FOR
for dato in datos:
    print(dato)'''

'''
CON BUCLE WHILE
n=0
while n<len(datos):
    print(datos[c])
    c+=1

'''