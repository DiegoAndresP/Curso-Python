'''Practica 01: Descuentos de un restaurante
Enunciado: un restaurante ofrece un descuento del 10% para consumo de hasta 
s/. 100.00 y un descuento del 20 % para consumos mayores, 
para ambos casos se aplica un impuesto del 19%. Determinar el monto del descuento, 
el impuesto y el importe a pagar.

Análisis: Para la solución de este problema, se requiere que el usuario ingrese el consumo 
y el sistema verifica y calcula el monto del descuento, el impuesto y el importe a pagar.

Monto del descuento
Impuesto
Importe a pagar'''

#Entrada "Consumo"
consumo=int(input('Ingrese su consumo: '))

#Proceso de validaciones

if consumo<=100:
    valor_descuento='10%'
    descuento=consumo*0.10
elif consumo>100:
    valor_descuento='20%'
    descuento=consumo*0.20

monto_decuento=consumo-descuento
igv=monto_decuento*0.19
total_pagar=monto_decuento+igv

#Salida
print('-------------------------')
print('          CUENTA         ')
print('Descuento por Aplicar', valor_descuento)
print('Monto Descuento: ',monto_decuento)
print('El impuesto añadido: ', igv)
print('El total a pagar es: ', total_pagar)








