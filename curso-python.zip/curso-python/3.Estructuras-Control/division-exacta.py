'''
Escriba un programa que pida dos números 
enteros y que calcule su división, escribiendo si la división es exacta o no.
'''


x=int(input('Ingrese Dividiendo: '))
y=int(input('Ingrese Divisor: '))

if y==0:
    print('No puede dividir en 0')
else:
    if residuo == 0:
        print('La division es Exacta')
    else:
        print('La division no es Exacta')

cociente= x//y
residuo= x%y

print(f'El cociente es: {cociente}')
print(f'El residuo es: {residuo}')
