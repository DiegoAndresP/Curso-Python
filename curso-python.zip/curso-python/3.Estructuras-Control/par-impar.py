"""Aplicación 01: Crear un sistema que detecte si número es par positivos o par negativo
y también si es impar positivo o negativos y si el numero ingresado es 0 
que detecte si es neutro.

Enunciado: determinar si un número entero es par positivo, impar positivo, par negativo,
 impar negativo o neutro.

Análisis: para la solución de este problema, se requiere que el usuario ingrese un número
 entero y el sistema verifique si es par positivo, impar positivo, par negativo, impar negativo
  o neutro."""


n= int (input('Ingrese un numero entero: '))
if n != 0:
    if n > 0:
        if n % 2 == 0:
                print(f'El numero {n} es Par Positivo')
        else:
                print(f'El numero {n} es Impar Positivo')
    else: 
            if n % 2 == 0:
             print(f'El numero {n} es Par Negativo')
            else:
             print(f'El numero {n} es negativo impar') 
else:
    print(f'El numero {n} es Neutro')
    












  