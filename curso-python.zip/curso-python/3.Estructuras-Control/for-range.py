for a in range(10):
 print(a)
