'''
Escriba un programa que pida dos números y 
que conteste cuál es el menor y cuál el mayor o que escriba que son iguales.
'''
x=int(input('Ingrese Numero: '))
y=int(input('Ingrese Numero: '))

if x>y:
    print(f'Mayor:{x} \n Menor: {y}')
elif x<y:
    print(f'Mayor:{y} \n Menor: {x}' )
else:
    print(f'Los numeros {x} y {y} son iguales')
