'''
Escribir un programa que pregunte al usuario su edad y
 muestre por pantalla todos los años que ha cumplido (desde 1 hasta su edad).
'''
edad=int(input('Ingrese Su Edad: '))
n=0
while n<edad:
    print(f'Has Cumplido {n} años')
    n+=1
    