numeros=[1,2,3,4,5,6,7,8,9,10,11,12]#Creamos lista
for num in numeros: #Almacenamos en num los valores de la lista
    if num % 2 ==0:#Condicion para pares
      print('Los numeros pares: ', num) 