'''
Escribir un programa que pida al usuario una palabra y la muestre por pantalla 10 veces.
'''


palabra=(input('Ingrese Una Palabra: '))
repetir=int(input('Ingrese veces a repetir: ' ))
i=0
while i<repetir:
    print(palabra)
    i+=1
    
    


