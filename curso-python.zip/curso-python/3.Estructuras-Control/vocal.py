"""Aplicación 02: Crear un sistema que detecte si un carácter es vocal o no
Enunciado: dado un carácter determinar si es una vocal.

Análisis: para la solución de este problema, se requiere que el usuario ingrese un carácter 
y el sistema verifique si es una vocal.
"""

v=input('Ingrese una vocal: ')
if v =='a' or v =='A':
   print(v,'Es una vocal')
elif v =='e' or v=='E':
   print(v,'Es una vocal')
elif v=='i' or v=='I':
    print(v,'Es una vocal')
elif v=='o' or v=='O':
    print(v,'Es una vocal')
elif v=='u' or v=='U':
    print(v,'Es una vocal')
else:
    print(v,'No es una vocal')

