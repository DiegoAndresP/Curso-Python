import random
def adivina_pc(x):
    print(f'Selecciona un numero entre 1 y {x}')

    inferior= 1
    superior= x
    respuesta= ''

    #Generando prediccion
    while respuesta != 'c':
        if inferior != superior:
            prediccion = random.randint(inferior, superior)
        else:
            prediccion= inferior
    #Obtener respuesta usuario
        respuesta=input(f'Mi prediccion es {prediccion}. Si el valor es alto ingresa (A), si el valor es muy bajo ingresa (B) y si es correcta ingresa (C)').lower()

        if respuesta == 'a':
            superior= prediccion-1
        elif respuesta == 'b':
            inferior = prediccion+1

    print(f'La computadora adivino tu numero: {prediccion}')


adivina_pc(10)

