import random

def jugar():
    user = input("Cual eliges? 'P' es piedra, 'T' es tijera, 'H' es papel: ") #El usuario elige con que quiere jugar
    bot = random.choice(['P','T','H']) #EL bot elige al azar
    print("EL Bot elige: ", bot)
    
    if user==bot:
        return 'EMPATE'
    
    if ganador(user, bot):
       return 'GANASTE'
    
    return 'PERDISTE'
    

# P>T, H>P T>H
def ganador(user,bot):
    
    return (user == 'P' and bot == 'T') or (user == 'H' and bot == 'P') or (user == 'T' and bot == 'H')

        
   
     
print(jugar())


    
