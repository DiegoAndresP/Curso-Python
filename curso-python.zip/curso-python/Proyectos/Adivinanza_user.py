#La computadora tiene un numero secreto y nosotros debemos adivinar cual es ese numero
import random  #Permite tomar un numero al azar

def adivina(x):
    random_number=random.randint(1, x)
    adivina=0
    while adivina != random_number:
        adivina=int(input(f'Adivina el numero entre 1 and {x}: '))
        if adivina < random_number:
         print('Lo siente ese no es el numero')
        elif adivina > random_number:
         print('Lo siento ese no es el numero')
    print(f'Has adivinado el numero {random_number}')

adivina(10)

