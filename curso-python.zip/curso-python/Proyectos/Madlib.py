"Consiste en que se tiene un texto y este tiene espacios los cuales debemos ir rellenando con verbos,adjetivos,etc"


objeto=input('Objeto: ')
verb1= input('verb1: ')
adv=input('adv: ')

madlib=f"Para programar uso una {objeto}, paso horas {verb1}, para poder {adv}"

print(madlib)
