from sys import argv
if len(argv)==4:
    nombre = argv[1]
    edad = int(argv[2])
    altura = float(argv[3])
    c = 0

    #print(f'Nombre: {nombre} \nEdad: {edad} \nAltura: {altura}')
    #print('Nombre: {} \nEdad: {} \nAltura: {}'.format(nombre, edad, altura))
    #print('Nombre: {n} \nEdad: {e} \nAltura: {a}'.format(a=altura, e=edad, n=nombre))
    #print(f'Nombre: %s \nEdad: %i \nAltura: %f'%(nombre, edad, altura))

    
    
else: 
    print("INGRESA ARGUMENTOS VALIDOS")
    print('formateo.py, "Nombre", "Edad", "Altura"')
