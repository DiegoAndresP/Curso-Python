def convertir(valor_dolar, pais):
    cantidad_moneda=float(input(f'Ingrese cantidad de {pais}: '))

    dolares = cantidad_moneda / valor_dolar
    dolares= round(dolares, 2)

    print(f'Tienes $ {dolares} Dolares')


def main():
    while True:
        menu = """
        1-Euros a Dolares
        2-Wones a Dolares
        3-Pesos Mexicanos a Dolares
        4-Libras a Dolares
        5-Salir
        Ingrese una Opcion: """

        opcion=input(menu)
        if opcion == '1':
            convertir(0.99, 'Euros')
        elif opcion == '2':
            convertir(1317.74, 'Wones')
        elif opcion == '3':
            convertir(20, 'Pesos Mexicanos')
        elif opcion == '4':
            convertir(0.84, 'Libras')
        elif opcion == '5':
            print('Cerrando Conversor')
            break
        else:
            print('Opcion Incorrecta')
            print('Por favor vuelva a ingresar una opcion')



        
if __name__=='__main__':
    main()



