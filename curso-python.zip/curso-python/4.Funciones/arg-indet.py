def sumar(*args, **kwargs): #El *args es para indicar argumentos indeterminados por posicion 
    #El **kwargs es para indicar argumentos indeterminados por nombre
    suma= 0
    for n in args:
        suma+=n
    return suma,kwargs
    
sumT, datos= sumar(1,2,3,4,5,5,3,636,3,63,1,63, nombre='Diego', edad=20)

print('Suma total es:', sumT)
print('Los datos son:', datos)


    