suma = lambda a,b: a+b
doblar= lambda n: n*2
par = lambda n: n%2==0
impar = lambda n: n%2!=0
invertir= lambda cadena: cadena[::-1]

c=input('ingrese una cadena: ')


print(doblar(10))
print(suma(10,20))
print(par(6))
print(impar(7))
print(invertir(c))
