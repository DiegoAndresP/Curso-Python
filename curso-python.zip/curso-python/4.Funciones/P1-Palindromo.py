'''Practica 01: Palíndromo
Crear un sistema que detecte si una palabra es palíndroma o no

Para solucionar este problema el usuario 
tiene que ingresar por pantalla una palabra y el sistema verificas si
es palíndromo o no.

Una palabra palíndroma se lee de igual formo como de la derecha y
de la izquierda.'''

def palindromo(palabra):
    palabra=palabra.replace(' ','')
    palabra= palabra.lower()
    palabra_invertida=palabra[::-1]

    if palabra == palabra_invertida:
        return True
    else:
        return False


#Funcion Principal
def main():
    palabra=input('Ingrese una Palabra: ')
    
    es_palindromo=palindromo(palabra)
    if es_palindromo:
        print('Si es palindromo')
    else:
        print('No es palindromo')

#Entrada a Aplicacion
if __name__=='__main__':
    main()