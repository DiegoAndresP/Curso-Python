
def saludar():
    global nombre
    nombre='Diego Andres' 
    edad=20
    return 'Hola desde funcion', nombre, edad
    #La funcion return es la quede establece el final de una funcion asi que en donde se coloque ahi sera el final de la funcion y tambien las instrucciones que esten despues del return no se ejecutaran
    
   
#Otra forma seria guardando en una variable
valor=saludar()
saludo,nombre,edad= saludar()
print(valor)
print(saludo)
print(nombre)
print(edad)
