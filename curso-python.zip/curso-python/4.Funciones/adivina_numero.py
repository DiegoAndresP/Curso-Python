import random


def jugar(vidas):
    random_number=random.randint(1, 100)
    numero_elegido = None
    while random_number != numero_elegido:
        numero_elegido = int(input('Ingrese un numero entre 1 y 100: '))
        if random_number < numero_elegido:
            print('Elige un numero mas pequeño')
            vidas-=1
            print(f'Te quedan {vidas} vidas')
        elif random_number > numero_elegido:
            print('Elige un numero mas grande')
            vidas-=1
            print(f'Te quedan {vidas} vidas')
        if vidas==0:
            print('Game Over')
            break
    if numero_elegido==random_number:
        print('Has Ganado')

def main():
    while True:
        menu= """
        ADIVINA EL NUMERO ALEATORIO
        >>Escoge un nivel
        1. Facil
        2. Intermedio
        3. Dificil
        4. Salir
        ELIJA UNA OPCION:
        """
        nivel= input(menu)

        if nivel == '1':
            jugar(10)
        elif nivel == '2':
            jugar(5)
        elif nivel == '3':
            jugar(3) 
        elif nivel == '4':
            print('CERRANDO JUEGO')
            break
        else:
            print('Ingrese una opcion valida')





if __name__=='__main__':
    main()

