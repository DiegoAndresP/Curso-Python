

def saludar():
    global nombre
    nombre='Diego Andres' 
    #Una variable definida dentra de una funcion puede usarse siempre dentro de una funcion unicamente
    #Ahora bien para poder usar una variable fuera de la funcion la podemos establecer como variable global

    print('Hola desde funcion')
    print('Hola', nombre)
   
saludar()#Para llamar una funcion siempre debe ser despues de que se defina

print('Hola desde fuera de funcion', nombre)

