#Ejemplo Funcion Recursividad->Estas son aquellas que se ejecutan asi mismas

def factorial(n):
    print('Valor Inicial= ', n)
    if n>1:
        n= n*factorial(n-1)#Aqui aplicamos la funcion recursiva donde la ejecutamos dentro de si misma
    #print('Valor Final: ', n )

    return n

n= int(input('Ingrese un numero: '))

f= factorial(n)  
print(f'Su factorial de {n} es: {f} ') 
