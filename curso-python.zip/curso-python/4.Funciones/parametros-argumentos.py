


def saludar(nombre): #Aqui establecemos un parametro
    return f'Hola, {nombre} desde funcion saludar'

def sumar(a, b):
    return a+b

def restar(a,b):
    return a-b

def multiplicar(a=None,b=None): # Argumentos por Defecto
    if a==None or b==None:
       print('Error se deben enviar 2 numeros a la funcion')
       return
    return a*b



saludo = saludar('Diego') #Aqui tenemos que enviar un argumento
print(saludo)

suma = sumar(5,5)#A esto se le llama argumentos por posicion done el primer argumento pertenece al primer parametro y el segundo argumento pertence al segundo parametro
print('La suma es:', suma)

resta = restar(a=10,b=5 )#A esto se le llama argumentos por nombre
print('La resta es:', resta)

multiplicacion= multiplicar()
print('La multiplicacion es:', multiplicacion)
