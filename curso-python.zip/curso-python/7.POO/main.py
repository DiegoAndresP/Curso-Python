from persona import Persona

persona1 = Persona('Gabriela', 18)


persona1.mostrar_datos()
print('='*25)

print(persona1)




