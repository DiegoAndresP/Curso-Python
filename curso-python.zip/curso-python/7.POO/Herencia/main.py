from persona import Cliente, Empleado

#cliente1 = Cliente('Diego', 21)
#cliente2 = Cliente('Gabriela', 18)

#cliente1.detalle_persona()
#print(cliente2)

empleado1 = Empleado('Diego', 21, 6000)
empleado2 = Empleado('Gabriela', 18, 3000)

print('Detalle Persona')
empleado1.detalle_persona()
print('='*25)

print('Detalle Empleado')
empleado1.detalle_empleado()
print('='*25)



print(empleado2)
