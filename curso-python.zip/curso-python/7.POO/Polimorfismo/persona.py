class Persona(object):
    def __init__(self, nombre):
        self.nombre = nombre

    def moverse(self):
        print('ANDO CAMINANDO')
    
class Atleta(Persona):

    def moverse(self):
        print('ANDO CORRIENDO')

class Ciclista(Persona):
    def moverse(self):
        print('ANDO EN BICI')