from persona import Persona, Atleta, Ciclista

persona = Persona('Diego')
persona.moverse()

atleta = Atleta('Emiliano')
atleta.moverse()

ciclista = Ciclista('Gabriela')
ciclista.moverse()
