from persona import Persona

persona1 = Persona('Diego', 21)
persona1.set__nombre('Gabriela')
#persona1.__metodo__privado

print(persona1.get__nombre())

print(persona1)




