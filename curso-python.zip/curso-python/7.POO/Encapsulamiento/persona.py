class Persona(object):
    __nombre = ' '
    __edad = ' '

    def __init__(self, nombre, edad):
        self.__nombre = nombre
        self.__edad = edad

    def __metodo__privado(self):
        print('Soy un metodo privado')


    def get__nombre(self):
        return self.__nombre

    def set__nombre(self, nombre):
        self.__nombre = nombre

    
    def get__edad(self):
        return self.__edad

    def set__edad(self, edad):
        self.__edad = edad

    
    
    def __str__(self):
        return f'Nombre: {self.__nombre} \nEdad: {self.__edad}'

    
    