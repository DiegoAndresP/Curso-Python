import my_paquete.aritmetica as a


def main():
    suma = a.suma(4,5,6,7,8,8)
    resta= a.restar(5,4)
    potencia = a.potencia(3,3)

    print('La suma es: ', suma)
    print('La resta es: ', resta)
    print('La potencia es: ', potencia)

if __name__ =='__main__':
    main()
    
