def suma(*args):
    suma = 0
    for n in args:
        suma+=n
    return suma


restar = lambda a,b: a-b

potencia = lambda a,b: a**b
